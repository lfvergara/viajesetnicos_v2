<div class="mkdf-register-notice">
	<h5 class="mkdf-register-notice-title"><?php echo esc_html($message); ?></h5>
</div>