<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/single-image/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/single-image/single-image.php';