<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/tabs/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/tabs/tabs.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/tabs/tabs-item.php';