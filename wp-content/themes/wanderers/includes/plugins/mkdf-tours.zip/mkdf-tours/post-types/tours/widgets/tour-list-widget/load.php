<?php

include_once MIKADO_TOURS_CPT_PATH . '/tours/widgets/tour-list-widget/functions.php';
include_once MIKADO_TOURS_CPT_PATH . '/tours/widgets/tour-list-widget/tour-list.php';