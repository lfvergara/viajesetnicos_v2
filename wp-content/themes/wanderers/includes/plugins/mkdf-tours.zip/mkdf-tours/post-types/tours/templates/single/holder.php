<div class="mkdf-grid <?php echo esc_attr($holder_class) ?>">
    <?php echo mkdf_tours_get_tour_module_template_part('single/single-item', 'tours', 'templates', '', $params); ?>
</div>