<?php

include_once MIKADO_TOURS_CPT_PATH . '/destinations/destinations-register.php';
include_once MIKADO_TOURS_CPT_PATH . '/destinations/helper-functions.php';