<?php

define('MIKADO_TOURS_VERSION', '1.0.5');
define('MIKADO_TOURS_ABS_PATH', dirname(__FILE__));
define('MIKADO_TOURS_REL_PATH', dirname(plugin_basename(__FILE__)));
define('MIKADO_TOURS_URL_PATH', plugin_dir_url( __FILE__ ));
define('MIKADO_TOURS_CPT_PATH', MIKADO_TOURS_ABS_PATH.'/post-types');
define('MIKADO_TOURS_ASSETS_PATH', MIKADO_TOURS_ABS_PATH.'/assets');
define('MIKADO_TOURS_ASSETS_URL_PATH', MIKADO_TOURS_URL_PATH.'assets');